import customtkinter as ctk
from security.password_generator import PasswordGenerator
from security.password_validator import PasswordValidator
from security.encryption import EncryptionManager


class DashboardUI(ctk.CTkFrame):

    def __init__(self, parent, add_callback, db, key):

        super().__init__(parent)

        self.add_callback = add_callback
        self.db = db
        self.key = key

        self.pack(fill="both", expand=True)

        # ===== TITLE =====
        ctk.CTkLabel(
            self,
            text="🔐 Password Vault",
            font=("Arial", 24)
        ).pack(pady=10)

        # ===== ADD ACCOUNT BUTTON =====
        ctk.CTkButton(
            self,
            text="+ Add New Account",
            command=self.toggle_form
        ).pack(pady=5)

        self.status = ctk.CTkLabel(self, text="")
        self.status.pack()

        # ===== VAULT DISPLAY =====
        self.vault_box = ctk.CTkTextbox(self, width=700, height=250)
        self.vault_box.pack(fill="both", expand=True, padx=20, pady=10)

        # ===== FORM =====
        self.form = ctk.CTkFrame(self)
        self.form_visible = False

        self.website = ctk.CTkEntry(self.form, placeholder_text="Website")
        self.website.pack(pady=5)

        self.username = ctk.CTkEntry(self.form, placeholder_text="Username")
        self.username.pack(pady=5)

        self.password = ctk.CTkEntry(self.form, placeholder_text="Password")
        self.password.pack(pady=5)

        # PASSWORD STRENGTH LABEL
        self.strength_label = ctk.CTkLabel(self.form, text="")
        self.strength_label.pack(pady=3)

        self.password.bind("<KeyRelease>", self.check_strength)

        ctk.CTkButton(
            self.form,
            text="Suggest Password",
            command=self.suggest
        ).pack(pady=5)

        ctk.CTkButton(
            self.form,
            text="Save Account",
            command=self.save
        ).pack(pady=5)

        self.load_vault()

    # ==========================
    # SHOW / HIDE FORM
    # ==========================
    def toggle_form(self):

        if not self.form_visible:
            self.form.pack(pady=10)
            self.form_visible = True
        else:
            self.form.pack_forget()
            self.form_visible = False

    # ==========================
    # PASSWORD STRENGTH
    # ==========================
    def check_strength(self, e=None):

        pw = self.password.get()

        if not pw:
            self.strength_label.configure(text="")
            return

        strength = PasswordValidator.analyze(pw)
        self.strength_label.configure(text=f"Strength: {strength}")

    # ==========================
    # PASSWORD SUGGESTION
    # ==========================
    def suggest(self):
        self.password.delete(0, "end")
        self.password.insert(0, PasswordGenerator.generate())
        self.check_strength()

    # ==========================
    # SAVE ACCOUNT
    # ==========================
    def save(self):

        self.add_callback(
            self.website.get(),
            self.username.get(),
            self.password.get()
        )

        self.status.configure(text="✅ Account Saved!")

        self.website.delete(0, "end")
        self.username.delete(0, "end")
        self.password.delete(0, "end")

        self.strength_label.configure(text="")

        # REFRESH LIST
        self.load_vault()

    # ==========================
    # LOAD VAULT DATA
    # ==========================
    def load_vault(self):

        self.vault_box.delete("1.0", "end")

        entries = self.db.get_all_entries()

        if not entries:
            self.vault_box.insert("end", "No accounts saved yet.")
            return

        for e in entries:

            website = e[1]
            username = e[2]
            encrypted = e[3]
            iv = e[4]

            try:
                decrypted = EncryptionManager.decrypt(
                    encrypted,
                    iv,
                    self.key
                )
            except:
                decrypted = "ERROR"

            line = (
                f"🌐 {website}\n"
                f"👤 {username}\n"
                f"🔑 {decrypted}\n"
                f"---------------------------\n"
            )

            self.vault_box.insert("end", line)