import customtkinter as ctk
class LoginUI(ctk.CTkFrame):
    def __init__(self,parent,callback):
        super().__init__(parent)
        self.pack(fill='both',expand=True)
        ctk.CTkLabel(self,text='Master Password',font=('Arial',22)).pack(pady=20)
        self.entry=ctk.CTkEntry(self,show='*')
        self.entry.pack(pady=10)
        self.msg=ctk.CTkLabel(self,text='')
        self.msg.pack()
        ctk.CTkButton(self,text='Login',
        command=lambda:callback(self.entry.get(),self.msg)).pack(pady=10)
