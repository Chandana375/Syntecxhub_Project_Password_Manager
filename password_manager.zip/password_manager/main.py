import customtkinter as ctk
import random
import time

from database.db import Database
from security.auth import AuthManager
from security.encryption import EncryptionManager
from ui.login_ui import LoginUI
from ui.dashboard_ui import DashboardUI


class App(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.title("Password Manager")
        self.geometry("900x650")
        self.minsize(800, 600)

        self.db = Database()
        self.key = None

        self.failed = 0
        self.lock_until = 0

        self.show_login()

    # ==========================
    # SHOW LOGIN PAGE
    # ==========================
    def show_login(self):
        LoginUI(self, self.login)

    # ==========================
    # LOGIN LOGIC
    # ==========================
    def login(self, master, msg):

        # cooldown protection
        if time.time() < self.lock_until:
            msg.configure(text="Cooldown active. Try later.")
            return

        user = self.db.get_user()

        # ===== FIRST TIME SETUP =====
        if not user:

            # generate NEW salt (IMPORTANT)
            salt = AuthManager.generate_salt()

            hashed = AuthManager.hash_master_password(master)

            self.db.insert_user(hashed, salt)

            self.key = EncryptionManager.derive_key(master, salt)

            msg.configure(text="Master key created successfully!")
            self.after(1000, self.show_dashboard)
            return

        # ===== LOGIN CHECK =====
        if AuthManager.verify_password(master, user[1]):

            self.failed = 0

            salt = user[2]

            # safety conversion
            if isinstance(salt, str):
                salt = salt.encode()

            self.key = EncryptionManager.derive_key(master, salt)

            # OTP simulation
            otp = random.randint(100000, 999999)
            print("OTP:", otp)

            msg.configure(text=f"OTP Sent: {otp}")
            self.after(1500, self.show_dashboard)

        else:

            self.failed += 1
            msg.configure(text=f"Login Failed ({self.failed}/3)")

            # lock after 3 attempts
            if self.failed >= 3:
                cooldown = random.randint(30, 120)
                self.lock_until = time.time() + cooldown
                msg.configure(text=f"LOCKED for {cooldown}s")

    # ==========================
    # SHOW DASHBOARD
    # ==========================
    def show_dashboard(self):

        for w in self.winfo_children():
            w.destroy()

        DashboardUI(
            self,
            self.add_password,
            self.db,
            self.key
        )

    # ==========================
    # ADD PASSWORD
    # ==========================
    def add_password(self, website, username, password):

        if not website or not username or not password:
            return

        enc, iv = EncryptionManager.encrypt(password, self.key)

        self.db.add_entry(
            website,
            username,
            enc,
            iv
        )


# ==========================
# RUN APP
# ==========================
if __name__ == "__main__":
    app = App()
    app.mainloop()