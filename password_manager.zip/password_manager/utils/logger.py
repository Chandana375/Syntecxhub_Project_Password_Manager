from datetime import datetime


def log(message):
    """
    Write activity logs into activity.log file
    """

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open("activity.log", "a", encoding="utf-8") as file:
        file.write(f"[{timestamp}] {message}\n")
