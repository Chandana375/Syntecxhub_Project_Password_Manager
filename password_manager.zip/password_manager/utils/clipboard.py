import pyperclip
import threading


def auto_clear(seconds=10):
    """
    Automatically clear clipboard after X seconds
    """

    def clear():
        pyperclip.copy("")
        print("Clipboard cleared for security.")

    threading.Timer(seconds, clear).start()
