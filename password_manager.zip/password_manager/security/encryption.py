import base64
import os
from hashlib import pbkdf2_hmac
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class EncryptionManager:

    # ==========================
    # KEY DERIVATION
    # ==========================
    @staticmethod
    def derive_key(master_password, salt):
        return pbkdf2_hmac(
            "sha256",
            master_password.encode(),
            salt,
            100000,
            dklen=32
        )

    # ==========================
    # ENCRYPT
    # ==========================
    @staticmethod
    def encrypt(text, key):

        iv = os.urandom(12)

        aes = AESGCM(key)

        encrypted = aes.encrypt(
            iv,
            text.encode(),
            None
        )

        return (
            base64.b64encode(encrypted).decode(),
            base64.b64encode(iv).decode()
        )

    # ==========================
    # DECRYPT  ⭐ (MISSING PART)
    # ==========================
    @staticmethod
    def decrypt(cipher_text, iv, key):

        aes = AESGCM(key)

        decrypted = aes.decrypt(
            base64.b64decode(iv),
            base64.b64decode(cipher_text),
            None
        )

        return decrypted.decode()