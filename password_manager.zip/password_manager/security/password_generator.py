import random
WORDS=['Nova','Tiger','Quantum','Matrix','River','Sky']
class PasswordGenerator:
    @staticmethod
    def generate():
        return random.choice(WORDS)+'!'+random.choice(WORDS)+str(random.randint(10,99))
