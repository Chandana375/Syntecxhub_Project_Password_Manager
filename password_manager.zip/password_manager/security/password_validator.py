import re,math
class PasswordValidator:
    @staticmethod
    def entropy(p):
        cs=0
        if re.search('[A-Z]',p): cs+=26
        if re.search('[a-z]',p): cs+=26
        if re.search('[0-9]',p): cs+=10
        if re.search('[^a-zA-Z0-9]',p): cs+=32
        if cs==0:return 0
        return len(p)*math.log2(cs)
    @staticmethod
    def analyze(p):
        e=PasswordValidator.entropy(p)
        if e<35:return 'Weak'
        elif e<55:return 'Medium'
        elif e<75:return 'Strong'
        return 'Very Strong'
