import bcrypt,os
class AuthManager:
    @staticmethod
    def generate_salt():
        return os.urandom(16)
    @staticmethod
    def hash_master_password(p):
        return bcrypt.hashpw(p.encode(),bcrypt.gensalt())
    @staticmethod
    def verify_password(p,h):
        return bcrypt.checkpw(p.encode(),h)
