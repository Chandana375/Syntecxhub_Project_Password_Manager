import time
class SessionManager:
    TIMEOUT=300
    def __init__(self):
        self.last=time.time()
    def refresh(self):
        self.last=time.time()
