import sqlite3
from datetime import datetime

class Database:

    def __init__(self):
        self.conn=sqlite3.connect("vault.db")
        self.create_tables()

    def create_tables(self):
        cur=self.conn.cursor()
        cur.execute('''CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY,
        master_hash BLOB,
        salt BLOB)''')

        cur.execute('''CREATE TABLE IF NOT EXISTS vault(
        id INTEGER PRIMARY KEY,
        website TEXT,
        username TEXT,
        encrypted_password TEXT,
        iv TEXT,
        notes TEXT,
        created_at TEXT)''')

        self.conn.commit()

    def insert_user(self,h,s):
        self.conn.execute("INSERT INTO users(master_hash,salt) VALUES(?,?)",(h,s))
        self.conn.commit()

    def get_user(self):
        return self.conn.execute("SELECT * FROM users LIMIT 1").fetchone()

    def add_entry(self,w,u,p,iv):
        self.conn.execute(
        "INSERT INTO vault(website,username,encrypted_password,iv,notes,created_at) VALUES(?,?,?,?,?,?)",
        (w,u,p,iv,"",str(datetime.now())))
        self.conn.commit()

    def get_all_entries(self):
        return self.conn.execute("SELECT * FROM vault").fetchall()
    